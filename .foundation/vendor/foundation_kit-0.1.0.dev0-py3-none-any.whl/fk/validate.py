"""`fk validate`: check every kit-owned file in a repository (spec §7, AC-09).

Covers `foundation.toml`, task front matter in `tasks/`, the decision register
`docs/DECISIONS.md` with its entries in `docs/decisions/`, and review records
under `reviews/`. Each problem is one line, "<path>: <message>". The gate's
`schema` check is this command's exit code.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path

from fk import config, frontmatter, schema

TASK_FILE = re.compile(r"(T-[0-9]{4,})-[a-z0-9]+(?:-[a-z0-9]+)*\.md")
DECISION_FILE = re.compile(r"(D-[0-9]{3,})-[a-z0-9]+(?:-[a-z0-9]+)*\.md")
REGISTER_LINE = re.compile(
    r"- \*\*(?P<id>D-[0-9]{3,})\*\* · (?P<date>\d{4}-\d{2}-\d{2}) · (?P<status>[a-z]+) · "
    r"(?P<sentence>.+?) → \[entry\]\((?P<link>decisions/(?P<link_id>D-[0-9]{3,})-[^)]+\.md)\)"
)
REVIEW_FILE = re.compile(r"(?P<sha>[0-9a-f]{40})-(?P<adapter>[a-z0-9-]+)\.json")
NEEDS_DONE = {"ready", "in_progress", "review", "accepted"}
DONE_HEADING = "## Definition of done"


@dataclass
class Report:
    problems: list[str] = field(default_factory=list)
    files: int = 0

    def add(self, rel: str, messages: list[str]) -> None:
        self.problems += [f"{rel}: {m}" for m in messages]

    @property
    def ok(self) -> bool:
        return not self.problems


def definition_of_done(body: str) -> list[str]:
    """The checklist items under '## Definition of done'."""
    items, inside = [], False
    for line in body.splitlines():
        if line.startswith("## "):
            inside = line.strip() == DONE_HEADING
            continue
        m = re.match(r"\s*- \[[ xX]\]\s+(\S.*)", line)
        if inside and m:
            items.append(m.group(1).strip())
    return items


def _read_front_matter(path: Path) -> tuple[dict | None, str, list[str]]:
    try:
        meta, body = frontmatter.parse(path.read_text(encoding="utf-8"))
    except (frontmatter.FrontMatterError, UnicodeDecodeError) as exc:
        return None, "", [str(exc)]
    return meta, body, []


def check_tasks(root: Path, report: Report) -> set[str]:
    ids: dict[str, str] = {}
    existing: set[str] = set()
    folder = root / "tasks"
    if not folder.is_dir():
        return set()
    for path in sorted(folder.glob("*.md")):
        if path.name == "README.md":
            continue
        rel = path.relative_to(root).as_posix()
        report.files += 1
        meta, body, problems = _read_front_matter(path)
        if meta is not None:
            problems = schema.validate(meta, schema.load("task"))
        name = TASK_FILE.fullmatch(path.name)
        if not name:
            problems.append("file name must be T-NNNN-<slug>.md (lower case)")
        else:
            # The task exists even when its front matter is broken, so its
            # reviews are not reported as orphans as well.
            existing.add(name.group(1))
        if meta is not None and not problems:
            problems += task_rules(meta, body, name.group(1))
            if meta["id"] in ids:
                problems.append(f"id {meta['id']} also used by {ids[meta['id']]}")
            ids.setdefault(meta["id"], rel)
        report.add(rel, problems)
    return existing | set(ids)


def task_rules(meta: dict, body: str, file_id: str) -> list[str]:
    problems = []
    if meta["id"] != file_id:
        problems.append(f"id {meta['id']} does not match the file name ({file_id})")
    if meta["updated"] < meta["created"]:
        problems.append("updated is earlier than created")
    blocked = meta["status"] == "blocked"
    if blocked != ("blocked_from" in meta):
        problems.append("blocked_from must be set exactly when status is blocked")
    state = meta.get("blocked_from", meta["status"])
    if state in NEEDS_DONE and not definition_of_done(body):
        problems.append(f"status {meta['status']} needs a non-empty '{DONE_HEADING}' checklist")
    return problems


def check_decisions(root: Path, report: Report) -> None:
    register = root / "docs" / "DECISIONS.md"
    folder = root / "docs" / "decisions"
    entries = {p.name: p for p in folder.glob("D-*.md")} if folder.is_dir() else {}
    if not register.is_file():
        if entries:
            report.add("docs/DECISIONS.md", ["missing, but docs/decisions/ has entries"])
        return
    report.files += 1
    rows: dict[str, dict] = {}
    problems = []
    for lineno, line in enumerate(register.read_text(encoding="utf-8").splitlines(), 1):
        if not line.startswith("- **D-"):
            continue
        m = REGISTER_LINE.fullmatch(line.rstrip())
        if not m:
            problems.append(f"line {lineno}: not a register line "
                            "(- **D-NNN** · YYYY-MM-DD · status · sentence → [entry](decisions/D-NNN-slug.md))")
            continue
        row = m.groupdict()
        if row["id"] in rows:
            problems.append(f"line {lineno}: {row['id']} appears twice")
            continue
        if row["link_id"] != row["id"]:
            problems.append(f"line {lineno}: {row['id']} links to {row['link_id']}'s entry")
        if row["status"] not in ("open", "current", "superseded"):
            problems.append(f"line {lineno}: status {row['status']!r} is not open, current or superseded")
        rows[row["id"]] = row
    report.add("docs/DECISIONS.md", problems)

    linked = set()
    for did, row in rows.items():
        rel = f"docs/{row['link']}"
        path = root / "docs" / row["link"]
        linked.add(path.name)
        if not path.is_file():
            report.add("docs/DECISIONS.md", [f"{did}: entry {rel} does not exist"])
            continue
        report.files += 1
        meta, _, problems = _read_front_matter(path)
        if meta is not None:
            problems = schema.validate(meta, schema.load("decision"))
        if meta is not None and not problems:
            for key, reg_key in (("id", "id"), ("status", "status")):
                if meta[key] != row[reg_key]:
                    problems.append(f"{key} {meta[key]} differs from the register ({row[reg_key]})")
            if str(meta["date"]) != row["date"]:
                problems.append(f"date {meta['date']} differs from the register ({row['date']})")
            if meta["status"] == "superseded":
                successor = meta.get("superseded_by")
                if not successor:
                    problems.append("superseded entries need superseded_by")
                elif successor not in rows:
                    problems.append(f"superseded_by {successor} is not in the register")
            elif "superseded_by" in meta:
                problems.append("superseded_by is set but status is not superseded")
        report.add(rel, problems)
    for name in sorted(set(entries) - linked):
        report.add(f"docs/decisions/{name}", ["not listed in docs/DECISIONS.md"])


def check_reviews(root: Path, report: Report, task_ids: set[str]) -> None:
    folder = root / "reviews"
    if not folder.is_dir():
        return
    review_schema = schema.load("review")
    for path in sorted(p for p in folder.rglob("*") if p.is_file()):
        rel = path.relative_to(root).as_posix()
        parts = path.relative_to(folder).parts
        if path.name in (".gitkeep", "README.md") and len(parts) == 1:
            continue
        report.files += 1
        m = REVIEW_FILE.fullmatch(path.name)
        if len(parts) != 2 or not m:
            report.add(rel, ["review records live at reviews/<task>/<40-char sha>-<adapter>.json"])
            continue
        problems = []
        if parts[0] not in task_ids:
            problems.append(f"no task {parts[0]} in tasks/")
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            report.add(rel, problems + [f"invalid JSON: {exc}"])
            continue
        problems += schema.validate(data, review_schema)
        if isinstance(data, dict) and data.get("head_sha") not in (None, m.group("sha")):
            problems.append("head_sha differs from the file name")
        report.add(rel, problems)


def validate_repo(root: Path) -> Report:
    root = Path(root)
    report = Report()
    report.files += 1
    _, problems = config.load(root)
    report.add(config.CONFIG_FILE, problems)
    task_ids = check_tasks(root, report)
    check_decisions(root, report)
    check_reviews(root, report, task_ids)
    return report

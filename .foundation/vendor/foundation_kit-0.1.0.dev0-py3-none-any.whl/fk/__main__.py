import sys

from fk.cli import main

sys.exit(main())

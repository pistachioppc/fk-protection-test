"""A small JSON Schema subset validator, standard library only.

Supported keywords: type (object, array, string, integer, boolean), required,
properties, additionalProperties (false or a schema), enum, pattern,
minLength, minimum, minItems, uniqueItems, items, format "date".

TOML dates arrive as `datetime.date`; a `format: date` string accepts those
and ISO date strings, so the same schema file serves TOML and JSON. Any other
keyword in a schema is an error in the schema, never silently ignored.
"""

from __future__ import annotations

import datetime as dt
import json
import re
from importlib import resources

SUPPORTED = {
    "$schema", "$id", "title", "description", "type", "required", "properties",
    "additionalProperties", "enum", "pattern", "minLength", "minimum",
    "minItems", "uniqueItems", "items", "format",
}
_TYPES = {
    "object": lambda v: isinstance(v, dict),
    "array": lambda v: isinstance(v, list),
    "string": lambda v: isinstance(v, str),
    "integer": lambda v: isinstance(v, int) and not isinstance(v, bool),
    "boolean": lambda v: isinstance(v, bool),
}
_ISO_DATE = re.compile(r"\d{4}-\d{2}-\d{2}")


class SchemaError(ValueError):
    """The schema itself is malformed or uses an unsupported keyword."""


def load(name: str) -> dict:
    """Load a schema shipped in fk/schemas/, e.g. load("task")."""
    text = resources.files("fk").joinpath("schemas", f"{name}.schema.json").read_text("utf-8")
    return json.loads(text)


def _where(path: str) -> str:
    return path or "(top level)"


def _is_date(value) -> bool:
    if isinstance(value, dt.datetime):
        return False
    if isinstance(value, dt.date):
        return True
    if isinstance(value, str) and _ISO_DATE.fullmatch(value):
        try:
            dt.date.fromisoformat(value)
            return True
        except ValueError:
            return False
    return False


def validate(value, schema: dict, path: str = "") -> list[str]:
    """Return a list of problems, each "<path>: <message>"; empty when valid."""
    unknown = set(schema) - SUPPORTED
    if unknown:
        raise SchemaError(f"unsupported schema keyword(s) at {_where(path)}: {sorted(unknown)}")
    where = _where(path)

    if schema.get("format") == "date":
        if not _is_date(value):
            return [f"{where}: {value!r} is not a date (YYYY-MM-DD)"]
        return []

    expected = schema.get("type")
    if expected is not None:
        if expected not in _TYPES:
            raise SchemaError(f"unsupported type {expected!r} at {where}")
        if not _TYPES[expected](value):
            return [f"{where}: expected {expected}, got {_type_name(value)}"]

    problems: list[str] = []
    if "enum" in schema and value not in schema["enum"]:
        options = ", ".join(str(o) for o in schema["enum"])
        problems.append(f"{where}: {value!r} is not one of {options}")
    if isinstance(value, str):
        if "minLength" in schema and len(value.strip()) < schema["minLength"]:
            problems.append(f"{where}: must not be empty")
        if "pattern" in schema and not re.search(schema["pattern"], value):
            problems.append(f"{where}: {value!r} does not match {schema['pattern']}")
    if _TYPES["integer"](value) and "minimum" in schema and value < schema["minimum"]:
        problems.append(f"{where}: {value} is below the minimum {schema['minimum']}")
    if isinstance(value, list):
        if "minItems" in schema and len(value) < schema["minItems"]:
            problems.append(f"{where}: needs at least {schema['minItems']} item(s)")
        if schema.get("uniqueItems") and len({json.dumps(v, sort_keys=True, default=str) for v in value}) != len(value):
            problems.append(f"{where}: items must be unique")
        if "items" in schema:
            for i, item in enumerate(value):
                problems += validate(item, schema["items"], f"{path}[{i}]")
    if isinstance(value, dict):
        props = schema.get("properties", {})
        for key in schema.get("required", []):
            if key not in value:
                problems.append(f"{where}: missing required key {key!r}")
        extra = schema.get("additionalProperties", True)
        for key, item in value.items():
            child = f"{path}.{key}" if path else key
            if key in props:
                problems += validate(item, props[key], child)
            elif extra is False:
                problems.append(f"{child}: unknown key")
            elif isinstance(extra, dict):
                problems += validate(item, extra, child)
    return problems


def _type_name(value) -> str:
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, dt.date):
        return "date"
    for name, check in _TYPES.items():
        if check(value):
            return name
    return type(value).__name__

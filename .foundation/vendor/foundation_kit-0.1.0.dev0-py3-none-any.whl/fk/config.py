"""Load and check `foundation.toml`, the client's configuration (spec §4.2)."""

from __future__ import annotations

import tomllib
from pathlib import Path

from fk import schema

CONFIG_FILE = "foundation.toml"


def check(data: dict) -> list[str]:
    """Schema problems plus the rules a schema cannot express."""
    problems = schema.validate(data, schema.load("config"))
    if problems:
        return problems
    names = [c["name"] for c in data["checks"]]
    for name in sorted({n for n in names if names.count(n) > 1}):
        problems.append(f"checks: duplicate check name {name!r}")
    for i, exc in enumerate(data.get("exceptions", [])):
        if exc["check"] not in names:
            problems.append(f"exceptions[{i}].check: {exc['check']!r} is not a configured check")
    github = data["github"]
    if github["agent"] and github["agent"].removesuffix("[bot]").lower() == github["human"].lower():
        problems.append("github.agent: must not be the human's own login")
    return problems


def load(root: Path) -> tuple[dict | None, list[str]]:
    """Return (config, problems). Config is None when it cannot be used."""
    path = Path(root) / CONFIG_FILE
    if not path.is_file():
        return None, ["missing"]
    try:
        data = tomllib.loads(path.read_text(encoding="utf-8"))
    except (tomllib.TOMLDecodeError, UnicodeDecodeError) as exc:
        return None, [f"invalid TOML: {exc}"]
    problems = check(data)
    return (None if problems else data), problems

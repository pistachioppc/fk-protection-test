"""A small GitHub REST client, standard library only (spec §5).

The human's token comes from `GH_TOKEN` or `GITHUB_TOKEN`, else from
`gh auth token`. The agent's installation token, used only to read the
agent App's own permissions, comes from `FK_AGENT_TOKEN`. Every failure
raises GitHubError: callers fail closed, never treat a failed read as "fine".
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

API = "https://api.github.com"
ACTIONS_APP_ID = 15368   # GitHub Actions: the source of the required checks


class GitHubError(RuntimeError):
    def __init__(self, message: str, status: int | None = None):
        super().__init__(message)
        self.status = status


def human_token() -> str:
    for name in ("GH_TOKEN", "GITHUB_TOKEN"):
        if os.environ.get(name):
            return os.environ[name]
    try:
        out = subprocess.run(["gh", "auth", "token"], capture_output=True, text=True,
                             timeout=30, stdin=subprocess.DEVNULL)
    except (OSError, subprocess.TimeoutExpired):
        out = None
    if out and out.returncode == 0 and out.stdout.strip():
        return out.stdout.strip()
    raise GitHubError("no GitHub token: set GH_TOKEN or sign in with `gh auth login`")


_REMOTE = re.compile(r"github\.com[:/]+([A-Za-z0-9._-]+)/([A-Za-z0-9._-]+?)(?:\.git)?/?$")


def repo_slug(root: Path, remote: str = "origin") -> str:
    """owner/name of the GitHub remote."""
    try:
        out = subprocess.run(["git", "remote", "get-url", remote], cwd=root, capture_output=True,
                             text=True, timeout=30)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise GitHubError(f"git remote: {exc}") from exc
    match = _REMOTE.search(out.stdout.strip()) if out.returncode == 0 else None
    if not match:
        raise GitHubError(f"remote {remote!r} is missing or not a GitHub repository")
    return f"{match.group(1)}/{match.group(2)}"


class Client:
    def __init__(self, token: str, api: str | None = None):
        self.token = token
        self.api = (api or os.environ.get("FK_GITHUB_API") or API).rstrip("/")

    def request(self, method: str, path: str, body: dict | None = None,
                ok: tuple[int, ...] = (200,)):
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(self.api + path, data=data, method=method, headers={
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "foundation-kit",
            **({"Content-Type": "application/json"} if data else {}),
        })
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                status, raw = resp.status, resp.read()
        except urllib.error.HTTPError as exc:
            status, raw = exc.code, exc.read()
        except (urllib.error.URLError, TimeoutError) as exc:
            raise GitHubError(f"{method} {path}: {exc}") from exc
        payload = json.loads(raw) if raw else None
        if status not in ok:
            message = payload.get("message", "") if isinstance(payload, dict) else ""
            raise GitHubError(f"{method} {path}: HTTP {status} {message}".rstrip(), status)
        return payload

    def get(self, path: str, ok: tuple[int, ...] = (200,)):
        return self.request("GET", path, ok=ok)

    def pages(self, path: str) -> list:
        out, page = [], 1
        sep = "&" if "?" in path else "?"
        while True:
            items = self.get(f"{path}{sep}per_page=100&page={page}")
            out.extend(items)
            if len(items) < 100:
                return out
            page += 1

    def file_text(self, repo: str, path: str, ref: str) -> str | None:
        """A file's text at `ref`, or None if it does not exist there."""
        import base64

        quoted = urllib.parse.quote(path)
        meta = self.get(f"/repos/{repo}/contents/{quoted}?ref={urllib.parse.quote(ref)}", ok=(200, 404))
        if not meta or "content" not in meta:
            return None
        return base64.b64decode(meta["content"]).decode("utf-8", errors="replace")

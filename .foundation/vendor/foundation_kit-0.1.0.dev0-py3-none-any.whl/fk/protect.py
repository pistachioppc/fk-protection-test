"""The default-branch ruleset of spec §5.2, and the checks that read it back.

`fk protect` shows the ruleset and, with `--apply`, creates or updates it:
an explicit external write the human runs. `fk doctor --remote` uses
`remote_findings` to decide PROTECTION: ENFORCED. Both use the same
definition, so what is applied is exactly what is checked.

On GitHub Free, rulesets work on public repositories only; a private
repository answers 403 "Upgrade to GitHub Pro" (verified 2026-11-16).
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path

from fk import config as cfg
from fk.github import ACTIONS_APP_ID, Client, GitHubError, human_token, repo_slug

NAME = "foundation"
CHECKS = ("foundation/gate", "foundation/guard")
CODEOWNERS_PATHS = (".github/CODEOWNERS", "CODEOWNERS", "docs/CODEOWNERS")  # GitHub's order
FORBIDDEN_APP_PERMISSIONS = ("administration", "workflows", "actions")


def separated(config: dict) -> bool:
    return bool(config["github"]["agent"])


def desired_ruleset(config: dict) -> dict:
    sep = separated(config)
    return {
        "name": NAME,
        "target": "branch",
        "enforcement": "active",
        "conditions": {"ref_name": {"include": ["~DEFAULT_BRANCH"], "exclude": []}},
        "bypass_actors": [],
        "rules": [
            {"type": "deletion"},
            {"type": "non_fast_forward"},
            {"type": "pull_request", "parameters": {
                # Unseparated: one identity cannot approve its own PR, so no review is required.
                "required_approving_review_count": 1 if sep else 0,
                "require_code_owner_review": sep,
                "dismiss_stale_reviews_on_push": True,
                "require_last_push_approval": sep,
                "required_review_thread_resolution": False,
            }},
            {"type": "required_status_checks", "parameters": {
                "strict_required_status_checks_policy": True,
                "do_not_enforce_on_create": False,
                "required_status_checks": [{"context": c, "integration_id": ACTIONS_APP_ID}
                                           for c in CHECKS],
            }},
        ],
    }


def ruleset_gaps(actual: dict | None, want: dict) -> list[str]:
    """What `actual` lacks of `want`. Extra server defaults are ignored."""
    if actual is None:
        return [f"ruleset {NAME!r} does not exist"]
    gaps = []
    if actual.get("enforcement") != "active":
        gaps.append(f"ruleset enforcement is {actual.get('enforcement')!r}, not 'active'")
    if actual.get("target") != "branch":
        gaps.append("ruleset does not target branches")
    include = (actual.get("conditions") or {}).get("ref_name", {}).get("include", [])
    if "~DEFAULT_BRANCH" not in include:
        gaps.append("ruleset does not cover the default branch (~DEFAULT_BRANCH)")
    if actual.get("bypass_actors"):
        gaps.append("ruleset has bypass actors: " + ", ".join(
            f"{b.get('actor_type')}:{b.get('actor_id')}" for b in actual["bypass_actors"]))
    have = {r["type"]: r.get("parameters", {}) for r in actual.get("rules", [])}
    for rule in want["rules"]:
        kind = rule["type"]
        if kind not in have:
            gaps.append(f"rule {kind} missing")
            continue
        for key, value in rule.get("parameters", {}).items():
            got = have[kind].get(key)
            if key == "required_status_checks":
                got_set = {(c.get("context"), c.get("integration_id")) for c in got or []}
                for c in value:
                    if (c["context"], c["integration_id"]) not in got_set:
                        gaps.append(f"required check {c['context']} (from GitHub Actions) missing")
            elif key == "required_approving_review_count":
                if not isinstance(got, int) or got < value:
                    gaps.append(f"{kind}.{key} is {got!r}, needs at least {value}")
            elif got != value:
                gaps.append(f"{kind}.{key} is {got!r}, needs {value!r}")
    return gaps


def codeowners_gaps(text: str | None, human: str) -> list[str]:
    """Every rule must name the human, and only the human, so their approval is the one that counts."""
    if text is None:
        return [f"no CODEOWNERS on the default branch: add .github/CODEOWNERS with '* @{human}'"]
    gaps, rules = [], []
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].strip()
        if line:
            pattern, *owners = line.split()
            rules.append((pattern, owners))
    if not rules or rules[0][0] != "*":
        gaps.append(f"CODEOWNERS must start with '* @{human}'")
    for pattern, owners in rules:
        if [o.lower() for o in owners] != [f"@{human}".lower()]:
            gaps.append(f"CODEOWNERS rule {pattern!r} has owners {' '.join(owners) or '(none)'}, "
                        f"needs only @{human}")
    return gaps


@dataclass
class Remote:
    repo: str
    client: Client
    default: str
    ruleset: dict | None
    ruleset_id: int | None


def connect(root: Path, config: dict) -> Remote:
    repo = repo_slug(root)
    client = Client(human_token())
    meta = client.get(f"/repos/{repo}")
    default = meta["default_branch"]
    found = [r for r in client.pages(f"/repos/{repo}/rulesets")
             if r.get("name") == NAME and r.get("source_type", "Repository") == "Repository"]
    if len(found) > 1:
        raise GitHubError(f"{len(found)} rulesets named {NAME!r}: remove the extras by hand")
    detail = client.get(f"/repos/{repo}/rulesets/{found[0]['id']}") if found else None
    return Remote(repo, client, default, detail, found[0]["id"] if found else None)


def _codeowners(remote: Remote) -> str | None:
    for path in CODEOWNERS_PATHS:
        text = remote.client.file_text(remote.repo, path, remote.default)
        if text is not None:
            return text
    return None


@dataclass
class Findings:
    ok: list[str] = field(default_factory=list)
    missing: list[str] = field(default_factory=list)

    @property
    def enforced(self) -> bool:
        return not self.missing


def remote_findings(root: Path, config: dict, agent_token: str | None = None) -> Findings:
    """Read every §5.2 item back from GitHub. Any read that fails is a missing item."""
    f = Findings()
    try:
        remote = connect(root, config)
    except GitHubError as exc:
        f.missing.append(f"cannot read the repository's rulesets: {exc}")
        return f
    human, agent = config["github"]["human"], config["github"]["agent"]
    want = desired_ruleset(config)

    gaps = ruleset_gaps(remote.ruleset, want)
    (f.missing.extend(gaps) if gaps else f.ok.append(f"ruleset {NAME!r} active on {remote.default}"))

    try:
        applied = {r["type"] for r in remote.client.get(f"/repos/{remote.repo}/rules/branches/{remote.default}")}
        absent = [r["type"] for r in want["rules"] if r["type"] not in applied]
        if absent:
            f.missing.append(f"GitHub does not report as applied on {remote.default}: {', '.join(absent)}")
        else:
            f.ok.append(f"GitHub reports the rules applied on {remote.default}")
    except GitHubError as exc:
        f.missing.append(f"cannot read the applied rules: {exc}")

    try:
        owners = codeowners_gaps(_codeowners(remote), human)
        (f.missing.extend(owners) if owners else f.ok.append(f"CODEOWNERS: * @{human}"))
    except GitHubError as exc:
        f.missing.append(f"cannot read CODEOWNERS: {exc}")

    try:
        wf = remote.client.get(f"/repos/{remote.repo}/actions/permissions/workflow")
        if wf.get("can_approve_pull_request_reviews") is False:
            f.ok.append("GitHub Actions cannot approve pull requests")
        else:
            f.missing.append("turn off 'Allow GitHub Actions to create and approve pull requests'")
    except GitHubError as exc:
        f.missing.append(f"cannot read the Actions approval setting: {exc}")

    if not agent:
        f.missing.append("ACCEPTANCE: SELF-MERGE (not separated): [github].agent is empty")
    elif agent.endswith("[bot]"):
        f.missing.extend(_app_gaps(remote, agent, agent_token, f))
    else:
        f.missing.extend(_account_gaps(remote, agent, f))
    return f


def _app_gaps(remote: Remote, agent: str, token: str | None, f: Findings) -> list[str]:
    slug = agent.removesuffix("[bot]")
    if not token:
        return [f"agent App permissions not verified: set FK_AGENT_TOKEN to an installation token of {slug}"]
    try:
        app = Client(token, remote.client.api).get(f"/apps/{slug}")
    except GitHubError as exc:
        return [f"cannot read the agent App {slug}: {exc}"]
    perms = app.get("permissions") or {}
    bad = [f"{p}:{perms[p]}" for p in FORBIDDEN_APP_PERMISSIONS if p in perms]
    if bad:
        return [f"agent App {slug} has forbidden permissions: {', '.join(bad)}"]
    f.ok.append(f"agent App {slug}: " + ", ".join(f"{k}:{v}" for k, v in sorted(perms.items())))
    return []


def _account_gaps(remote: Remote, agent: str, f: Findings) -> list[str]:
    try:
        role = remote.client.get(f"/repos/{remote.repo}/collaborators/{agent}/permission").get("role_name")
    except GitHubError as exc:
        return [f"cannot read the agent account's role: {exc}"]
    if role != "write":
        return [f"agent account {agent} has role {role!r}; it must be 'write' (no admin or maintain)"]
    f.ok.append(f"agent account {agent}: write")
    return []


def protect(root: Path, apply: bool = False) -> int:
    """`fk protect [--apply]`: 0 when the ruleset is (or now is) in place, 1 otherwise."""
    config, problems = cfg.load(root)
    if config is None:
        print(f"fk protect: foundation.toml: {'; '.join(problems)}")
        return 1
    try:
        remote = connect(root, config)
        owners = codeowners_gaps(_codeowners(remote), config["github"]["human"])
    except GitHubError as exc:
        print(f"fk protect: {exc}")
        return 1
    want = desired_ruleset(config)
    gaps = ruleset_gaps(remote.ruleset, want)
    action = "unchanged" if not gaps else ("update" if remote.ruleset else "create")
    print(f"repository: {remote.repo} (default branch {remote.default})")
    print(f"ruleset {NAME!r}: {action}")
    for gap in gaps:
        print(f"  - {gap}")
    for gap in owners:
        print(f"CODEOWNERS: {gap}")
    if not separated(config):
        print("ACCEPTANCE: SELF-MERGE (not separated): no review is required, so this is not protection")
    if action == "unchanged":
        return 1 if owners else 0
    if not apply:
        print(json.dumps(want, indent=2))
        print("dry run: nothing written; run `fk protect --apply` to write this ruleset")
        return 1
    if owners:
        print("fk protect: refusing --apply until CODEOWNERS is on the default branch")
        return 1
    try:
        if remote.ruleset_id:
            remote.client.request("PUT", f"/repos/{remote.repo}/rulesets/{remote.ruleset_id}", want)
        else:
            remote.client.request("POST", f"/repos/{remote.repo}/rulesets", want, ok=(201,))
        after = connect(root, config)
    except GitHubError as exc:
        print(f"fk protect: {exc}")
        return 1
    left = ruleset_gaps(after.ruleset, want)
    for gap in left:
        print(f"  still missing: {gap}")
    print(f"ruleset {NAME!r}: {'written and read back' if not left else 'written, but read-back differs'}")
    print("Check it once in GitHub: Settings > Rules > Rulesets. Then run `fk doctor --remote`.")
    return 1 if left else 0


def agent_token() -> str | None:
    return os.environ.get("FK_AGENT_TOKEN") or None

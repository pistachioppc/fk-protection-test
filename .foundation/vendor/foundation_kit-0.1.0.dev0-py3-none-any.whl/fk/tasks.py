"""`fk task new|move|show|list`: task files and their state machine (spec §4.2).

    proposed → ready → in_progress → review → accepted
    any non-terminal state → blocked → (back to the state it left)
    any non-terminal state → cancelled

`ready` needs a non-empty definition of done. `review` needs a branch that is
pushed and a pull request number. `accepted` is never set here: only `fk sync`
sets it, from a merged and human-approved pull request (§4.1).
"""

from __future__ import annotations

import datetime as dt
import os
import re
import subprocess
import tempfile
import unicodedata
from dataclasses import dataclass
from pathlib import Path

from fk import config, frontmatter, schema, validate

TASKS_DIR = "tasks"
STATES = ("proposed", "ready", "in_progress", "review", "accepted", "blocked", "cancelled")
TERMINAL = {"accepted", "cancelled"}
FORWARD = {"proposed": "ready", "ready": "in_progress", "in_progress": "review"}
SLUG_MAX = 40

BODY = """
## Why

## Definition of done

## Notes

## Evidence
<!-- fk writes gate runs, review records and the PR link here -->
"""


class TaskError(Exception):
    """A refused task command; the message says why."""


@dataclass
class Task:
    path: Path
    meta: dict
    body: str
    text: str

    @property
    def id(self) -> str:
        return self.meta["id"]


def slugify(text: str) -> str:
    """Lower-case ASCII words joined by hyphens, cut at a word boundary."""
    ascii_text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()
    words = re.findall(r"[a-z0-9]+", ascii_text.lower())
    slug = ""
    for word in words:
        candidate = f"{slug}-{word}" if slug else word
        if len(candidate) > SLUG_MAX:
            break
        slug = candidate
    return slug or (words[0][:SLUG_MAX] if words else "untitled")


def write_atomic(path: Path, text: str) -> None:
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as fh:
            fh.write(text)
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


def normalise_id(raw: str) -> str:
    """'T-0007', 't-7' and '7' all mean T-0007."""
    m = re.fullmatch(r"(?:[Tt]-)?0*([0-9]+)", raw.strip())
    if not m:
        raise TaskError(f"{raw!r} is not a task id (T-NNNN)")
    return f"T-{int(m.group(1)):04d}"


def _files(root: Path) -> list[tuple[str, Path]]:
    folder = root / TASKS_DIR
    if not folder.is_dir():
        return []
    found = []
    for path in sorted(folder.glob("T-*.md")):
        m = validate.TASK_FILE.fullmatch(path.name)
        if m:
            found.append((m.group(1), path))
    return found


def next_id(root: Path) -> str:
    numbers = [int(tid[2:]) for tid, _ in _files(root)]
    return f"T-{max(numbers, default=0) + 1:04d}"


def load(path: Path) -> Task:
    text = path.read_text(encoding="utf-8")
    try:
        meta, body = frontmatter.parse(text)
    except frontmatter.FrontMatterError as exc:
        raise TaskError(f"{path.name}: {exc}") from exc
    return Task(path, meta, body, text)


def find(root: Path, raw_id: str) -> Task:
    tid = normalise_id(raw_id)
    paths = [p for t, p in _files(root) if t == tid]
    if not paths:
        raise TaskError(f"no task {tid} in {TASKS_DIR}/")
    if len(paths) > 1:
        raise TaskError(f"{tid} has more than one file: " + ", ".join(p.name for p in paths))
    return load(paths[0])


def all_tasks(root: Path) -> tuple[list[Task], list[str]]:
    """Every readable task, plus one line per file that could not be read."""
    tasks, problems = [], []
    for _, path in _files(root):
        try:
            tasks.append(load(path))
        except TaskError as exc:
            problems.append(str(exc))
    return tasks, problems


def _problems(meta: dict, body: str, file_id: str) -> list[str]:
    problems = schema.validate(meta, schema.load("task"))
    return problems or validate.task_rules(meta, body, file_id)


def new(root: Path, title: str, today: dt.date | None = None) -> Path:
    title = " ".join(title.split())
    if not title:
        raise TaskError("the title is empty")
    today = today or dt.date.today()
    tid = next_id(root)
    meta = {"id": tid, "title": title, "status": "proposed"}
    cfg, _ = config.load(root)
    if cfg:
        meta["owner"] = cfg["agents"]["builder"]
        meta["reviewer"] = cfg["agents"]["reviewer"]
    meta.update(created=today, updated=today)
    text = frontmatter.dumps(meta, BODY)
    # The state list as a comment beside status, as in the spec's example.
    text = text.replace('status = "proposed"\n',
                        'status = "proposed"           # ' + " | ".join(STATES) + "\n", 1)
    problems = _problems(*frontmatter.parse(text), tid)
    if problems:
        raise TaskError("; ".join(problems))
    folder = root / TASKS_DIR
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"{tid}-{slugify(title)}.md"
    with path.open("x", encoding="utf-8") as fh:
        fh.write(text)
    return path


def allowed(meta: dict) -> list[str]:
    """The states a task may move to with `fk task move`."""
    status = meta["status"]
    if status in TERMINAL:
        return []
    if status == "blocked":
        return [meta["blocked_from"], "cancelled"]
    return [s for s in (FORWARD.get(status), "blocked", "cancelled") if s]


def _pushed(root: Path, branch: str) -> bool:
    """True when some remote-tracking ref carries `branch`."""
    try:
        out = subprocess.run(
            ["git", "for-each-ref", "--format=%(refname)", "refs/remotes/"],
            cwd=root, capture_output=True, text=True, check=True,
        ).stdout
    except (OSError, subprocess.CalledProcessError):
        return False
    return any(ref.split("/", 3)[-1] == branch for ref in out.split())


def move(root: Path, raw_id: str, state: str, branch: str | None = None,
         pr: int | None = None, today: dt.date | None = None) -> tuple[Task, str]:
    """Move a task to `state`; return (task after the move, state it left)."""
    task = find(root, raw_id)
    file_id = validate.TASK_FILE.fullmatch(task.path.name).group(1)
    problems = _problems(task.meta, task.body, file_id)
    if problems:
        raise TaskError(f"{task.path.name} is not valid, fix it first: " + "; ".join(problems))
    status = task.meta["status"]
    if state == "accepted":
        raise TaskError("accepted is set only by `fk sync`, from a merged pull request "
                        "with a passing gate and the human's approval")
    if state not in STATES:
        raise TaskError(f"unknown state {state!r}")
    if state == status:
        raise TaskError(f"{task.id} is already {status}")
    options = allowed(task.meta)
    if state not in options:
        where = ", ".join(o for o in options if o != "accepted") or "nothing (terminal)"
        raise TaskError(f"{task.id} cannot move from {status} to {state}; allowed: {where}")

    changes: dict = {"status": state, "updated": today or dt.date.today()}
    remove: tuple[str, ...] = ()
    if branch is not None:
        changes["branch"] = branch
    if pr is not None:
        changes["pr"] = pr
    if state == "blocked":
        changes["blocked_from"] = status
    elif status == "blocked":
        remove = ("blocked_from",)
    if state == "ready" and not validate.definition_of_done(task.body):
        raise TaskError(f"{task.id} needs a non-empty '{validate.DONE_HEADING}' checklist "
                        "(lines '- [ ] ...') before it is ready")
    if state == "review":
        b = changes.get("branch", task.meta.get("branch"))
        n = changes.get("pr", task.meta.get("pr"))
        if not b or not n:
            raise TaskError(f"{task.id} needs a branch and a pull request for review "
                            "(--branch NAME --pr NUMBER)")
        if not _pushed(root, b):
            raise TaskError(f"branch {b} is not pushed (no remote-tracking ref); push it first")

    text = frontmatter.update(task.text, changes, remove=remove)
    meta, body = frontmatter.parse(text)
    problems = _problems(meta, body, file_id)
    if problems:
        raise TaskError("; ".join(problems))
    write_atomic(task.path, text)
    return Task(task.path, meta, body, text), status

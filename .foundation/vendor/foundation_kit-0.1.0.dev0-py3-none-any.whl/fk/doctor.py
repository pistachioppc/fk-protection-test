"""`fk doctor [--remote] [--strict]` (spec §5.2, §10).

Local: configuration valid, check tools on PATH, a GitHub remote. Remote:
every §5.2 item read back from GitHub, ending in one line,
PROTECTION: ENFORCED or PROTECTION: NOT ENFORCED. The line is evidence, not a
control: this code runs where the agent works, so the human checks the ruleset
in GitHub once after `fk protect --apply`.
"""

from __future__ import annotations

import shlex
import shutil
from pathlib import Path

from fk import config as cfg
from fk import protect
from fk.github import GitHubError, repo_slug

EXIT_OK, EXIT_FAIL, EXIT_NOT_ENFORCED = 0, 1, 4


def local_problems(root: Path, config: dict) -> tuple[list[str], list[str]]:
    ok, bad = [], []
    for check in config["checks"]:
        argv = shlex.split(check["run"])
        tool = argv[0] if argv else ""
        if tool == "fk" or shutil.which(tool):
            ok.append(f"check {check['name']}: {tool} found")
        elif check["required"]:
            bad.append(f"check {check['name']}: {tool} not on PATH (the gate will fail)")
        else:
            ok.append(f"check {check['name']}: {tool} not on PATH (not required)")
    try:
        ok.append(f"remote: {repo_slug(root)}")
    except GitHubError as exc:
        bad.append(f"remote: {exc}")
    return ok, bad


def doctor(root: Path, remote: bool = False, strict: bool = False) -> int:
    config, problems = cfg.load(root)
    if config is None:
        print(f"FAIL foundation.toml: {'; '.join(problems)}")
        return EXIT_FAIL
    print("ok   foundation.toml")
    ok, bad = local_problems(root, config)
    for line in ok:
        print(f"ok   {line}")
    for line in bad:
        print(f"FAIL {line}")
    if not remote:
        print("PROTECTION: not checked (run `fk doctor --remote`)")
        return EXIT_FAIL if bad else EXIT_OK
    found = protect.remote_findings(root, config, protect.agent_token())
    for line in found.ok:
        print(f"ok   {line}")
    for line in found.missing:
        print(f"FAIL {line}")
    print("PROTECTION: ENFORCED" if found.enforced else "PROTECTION: NOT ENFORCED")
    if bad:
        return EXIT_FAIL
    if strict and not found.enforced:
        return EXIT_NOT_ENFORCED
    return EXIT_OK

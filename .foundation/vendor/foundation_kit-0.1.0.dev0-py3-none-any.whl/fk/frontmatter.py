"""Markdown with TOML front matter between `+++` fences (spec §4.2).

Reading accepts any TOML that `tomllib` accepts. Writing covers the flat
subset the kit's own files use: bare keys whose values are strings, integers,
booleans, dates, or one-line arrays of those. `update` rewrites only the lines
of the keys it changes, so comments and key order survive.
"""

from __future__ import annotations

import datetime as dt
import re
import tomllib

FENCE = "+++"
_BARE_KEY = re.compile(r"[A-Za-z0-9_-]+")
_TABLE_HEADER = re.compile(r"\s*\[\[?[A-Za-z0-9_.\" -]+\]\]?\s*(#.*)?$")


class FrontMatterError(ValueError):
    pass


def split(text: str) -> tuple[str, str]:
    """Return (front matter source, body). Raises if the fences are missing."""
    lines = text.splitlines(keepends=True)
    if not lines or lines[0].rstrip("\r\n") != FENCE:
        raise FrontMatterError("no front matter: the file must start with a '+++' line")
    for i in range(1, len(lines)):
        if lines[i].rstrip("\r\n") == FENCE:
            return "".join(lines[1:i]), "".join(lines[i + 1 :])
    raise FrontMatterError("front matter is not closed: no second '+++' line")


def parse(text: str) -> tuple[dict, str]:
    """Return (metadata, body)."""
    source, body = split(text)
    try:
        return tomllib.loads(source), body
    except tomllib.TOMLDecodeError as exc:
        raise FrontMatterError(f"invalid TOML in front matter: {exc}") from exc


def format_value(value) -> str:
    # bool before int: bool is a subclass of int.
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, str):
        return _basic_string(value)
    if isinstance(value, dt.datetime):
        raise FrontMatterError("datetimes are outside the flat subset; use a date")
    if isinstance(value, dt.date):
        return value.isoformat()
    if isinstance(value, list):
        items = []
        for item in value:
            if isinstance(item, list):
                raise FrontMatterError("nested arrays are outside the flat subset")
            items.append(format_value(item))
        return "[" + ", ".join(items) + "]"
    raise FrontMatterError(f"{type(value).__name__} is outside the flat subset")


def _basic_string(s: str) -> str:
    out = []
    for ch in s:
        if ch == '"':
            out.append('\\"')
        elif ch == "\\":
            out.append("\\\\")
        elif ch == "\n":
            out.append("\\n")
        elif ch == "\t":
            out.append("\\t")
        elif ch == "\r":
            out.append("\\r")
        elif ord(ch) < 0x20 or ord(ch) == 0x7F:
            out.append(f"\\u{ord(ch):04X}")
        else:
            out.append(ch)
    return '"' + "".join(out) + '"'


def _check_key(key: str) -> None:
    if not _BARE_KEY.fullmatch(key):
        raise FrontMatterError(f"key {key!r} is outside the flat subset (bare keys only)")


def dumps(meta: dict, body: str = "") -> str:
    """Write a document from metadata (flat subset) and a body."""
    lines = [FENCE]
    for key, value in meta.items():
        _check_key(key)
        lines.append(f"{key} = {format_value(value)}")
    lines.append(FENCE)
    return "\n".join(lines) + "\n" + body


def _value_end(line: str, start: int) -> int | None:
    """Index just past the TOML value that starts at `start`, or None if it
    does not end on this line (a multi-line value)."""
    i, depth, n = start, 0, len(line)
    while i < n:
        ch = line[i]
        if ch in "\"'":
            if line.startswith(ch * 3, i):
                return None
            j = i + 1
            while j < n and line[j] != ch:
                j += 2 if ch == '"' and line[j] == "\\" else 1
            if j >= n:
                return None
            i = j + 1
            if depth == 0:
                return i
            continue
        if ch == "[":
            depth += 1
        elif ch == "]":
            depth -= 1
            if depth == 0:
                return i + 1
        elif depth == 0 and ch in "#\r\n":
            return len(line[:i].rstrip())
        i += 1
    return None if depth else len(line.rstrip())


def update(text: str, changes: dict, remove: tuple[str, ...] = ()) -> str:
    """Set keys in the front matter, keeping every other line as it is.

    A key already present is rewritten in place with its trailing comment; a
    new key is appended before the closing fence. Keys in `remove` lose their
    line. The result is parsed again and must carry exactly the requested
    values, and none of the removed keys.
    """
    meta, _ = parse(text)
    lines = text.splitlines(keepends=True)
    close = next(i for i in range(1, len(lines)) if lines[i].rstrip("\r\n") == FENCE)
    # Top-level keys end at the first table header; new keys go before it.
    end = next((i for i in range(1, close) if _TABLE_HEADER.match(lines[i])), close)
    for key in remove:
        _check_key(key)
        if key in changes:
            raise FrontMatterError(f"key {key!r} is both set and removed")
        if key not in meta:
            continue
        pattern = re.compile(rf"^\s*{re.escape(key)}\s*=\s*")
        for i in range(1, end):
            m = pattern.match(lines[i])
            if m:
                if _value_end(lines[i], m.end()) is None:
                    raise FrontMatterError(f"key {key!r} has a multi-line value; edit it by hand")
                del lines[i]
                end -= 1
                break
        else:
            raise FrontMatterError(f"key {key!r} is not a top-level bare key line")
    added = []
    for key, value in changes.items():
        _check_key(key)
        new_value = format_value(value)
        pattern = re.compile(rf"^(\s*{re.escape(key)}\s*=\s*)")
        for i in range(1, end):
            m = pattern.match(lines[i])
            if not m:
                continue
            stop = _value_end(lines[i], m.end())
            if stop is None:
                raise FrontMatterError(f"key {key!r} has a multi-line value; edit it by hand")
            lines[i] = m.group(1) + new_value + lines[i][stop:]
            break
        else:
            if key in meta:
                raise FrontMatterError(f"key {key!r} is not a top-level bare key line")
            added.append(f"{key} = {new_value}\n")
    lines[end:end] = added
    result = "".join(lines)
    got, _ = parse(result)
    for key, value in changes.items():
        if got.get(key) != value:
            raise FrontMatterError(f"update of {key!r} did not round-trip")
    for key in remove:
        if key in got:
            raise FrontMatterError(f"removal of {key!r} did not round-trip")
    return result

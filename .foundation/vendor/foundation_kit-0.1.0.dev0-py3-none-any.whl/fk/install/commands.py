"""`fk init`, `fk upgrade`, `fk uninstall` and `fk upgrade --resolve` (spec §10, §12).

Each command plans first, prints the plan, and with `--dry-run` stops there.
Otherwise it refuses a dirty tree, creates a new branch, writes exactly the
plan and commits it. Nothing is ever written on the branch you are on.
"""

from __future__ import annotations

import tomllib
from pathlib import Path

import fk
from fk.install import apply, plan
from fk.install import manifest as mf
from fk.install.plan import NEW_SUFFIX, WRITES, InstallError

EXIT_OK, EXIT_FAIL, EXIT_CONFLICT = 0, 1, 3

GITHUB_STEPS = """\
Undo on GitHub (the human, in the repository's Settings):
  1. Rules > Rulesets: delete the foundation ruleset.
  2. Remove the CODEOWNERS line that names the human, if it was added for the kit.
  3. GitHub Apps: uninstall the agent app from this repository.
  4. Labels: delete control-change-approved."""


def _stack(root: Path) -> str:
    try:
        data = tomllib.loads((root / "foundation.toml").read_text(encoding="utf-8"))
        stack = data["project"]["stack"]
        if stack in ("python", "node"):
            return stack
    except (OSError, tomllib.TOMLDecodeError, KeyError, TypeError):
        pass
    return plan.detect_stack(root)


def _default_branch(root: Path) -> str:
    try:
        data = tomllib.loads((root / "foundation.toml").read_text(encoding="utf-8"))
        return data["project"]["default_branch"]
    except (OSError, tomllib.TOMLDecodeError, KeyError, TypeError):
        return "main"


def _print_plan(title: str, items: list[plan.Item], dry_run: bool) -> None:
    print(f"{title}{' (dry run)' if dry_run else ''}")
    for line in apply.describe(items):
        print(line)
    if dry_run:
        diff = apply.diffs(items)
        if diff:
            print()
            print("".join(diff), end="")
        print("dry run: nothing written")


def _conflicts(items: list[plan.Item]) -> list[str]:
    return [it.path for it in items if it.action == "conflict"]


def _commit(root: Path, branch: str, message: str, items, manifest, allow_dirty: bool) -> str:
    if not allow_dirty:
        apply.require_clean(root)
    if apply.branch_exists(root, branch):
        raise InstallError(f"branch {branch} already exists; delete it or merge it first")
    apply.git(root, "checkout", "-q", "-b", branch)
    touched = apply.write_plan(root, items, manifest)
    # -f: the plan's own paths go in even when an ignore rule matches one
    # (a conflict file such as .env.example.foundation-new).
    apply.git(root, "add", "-A", "-f", "--", *touched)
    apply.git(root, "commit", "-q", "-m", message)
    sha = apply.git(root, "rev-parse", "--short", "HEAD").strip()
    print(f"committed {len(touched)} path(s) on branch {branch} ({sha}); open a pull request to merge it")
    return sha


def init(root: Path, stack: str | None = None, dry_run: bool = False, allow_dirty: bool = False,
         templates: Path | None = None, version: str = fk.__version__) -> int:
    root = Path(root)
    apply.require_repo(root)
    old = mf.Manifest.read(root)
    stack = stack or _stack(root)
    desired = plan.desired_files(templates or plan.kit_templates(), stack, version)
    items = plan.install_plan(root, desired, old)
    writes = any(it.action in WRITES for it in items)
    if old and writes:
        print(f"already installed (kit {old.kit_version}); run fk upgrade")
        return EXIT_FAIL
    _print_plan(f"fk init {version}, stack {stack}", items, dry_run)
    if dry_run:
        return EXIT_OK
    if not writes:
        print("nothing to write")
        return EXIT_OK
    _commit(root, f"foundation/install-{version}", f"foundation: install kit {version}",
            items, plan.next_manifest(items, old, version), allow_dirty)
    for path in _conflicts(items):
        print(f"conflict: {path} exists; the kit's version is in {path}{NEW_SUFFIX}")
    return EXIT_OK


def upgrade(root: Path, dry_run: bool = False, allow_dirty: bool = False,
            templates: Path | None = None, version: str = fk.__version__) -> int:
    root = Path(root)
    apply.require_repo(root)
    old = mf.Manifest.read(root)
    if old is None:
        raise InstallError("not installed: no .foundation/manifest.json; run fk init")
    desired = plan.desired_files(templates or plan.kit_templates(), _stack(root), version)
    items = plan.install_plan(root, desired, old)
    if not any(it.action in WRITES for it in items) and old.kit_version == version:
        print(f"up to date (kit {version})")
        return EXIT_OK
    _print_plan(f"fk upgrade {old.kit_version} -> {version}", items, dry_run)
    conflicts = _conflicts(items)
    if not dry_run:
        _commit(root, f"foundation/upgrade-{version}", f"foundation: upgrade kit to {version}",
                items, plan.next_manifest(items, old, version), allow_dirty)
    if conflicts:
        print(f"{len(conflicts)} conflict(s): the client edited these managed files")
        for path in conflicts:
            print(f"  {path}: compare with {path}{NEW_SUFFIX}, then fk upgrade --resolve {path} keep|theirs")
        return EXIT_CONFLICT
    return EXIT_OK


def resolve(root: Path, path: str, choice: str, templates: Path | None = None,
            version: str = fk.__version__) -> int:
    root = Path(root)
    apply.require_repo(root)
    old = mf.Manifest.read(root)
    if old is None:
        raise InstallError("not installed: no .foundation/manifest.json")
    if choice not in ("keep", "theirs"):
        raise InstallError("resolve takes keep or theirs")
    branch = apply.current_branch(root)
    if branch == _default_branch(root):
        raise InstallError(f"refusing to write on the default branch {branch}; check out the upgrade branch")
    desired = plan.desired_files(templates or plan.kit_templates(), _stack(root), version)
    items = {it.path: it for it in plan.install_plan(root, desired, old)}
    it = items.get(path)
    if it is None or it.action != "conflict":
        raise InstallError(f"{path} is not in conflict")
    rec = dict(old.files.get(path, {"class": it.cls, "sha256": None}))
    if choice == "keep":
        rec["kept"] = mf.sha256(it.kit)
    else:
        new = plan._with_block(it.current, it.kit) if it.cls == mf.BLOCK else it.kit
        apply.write_atomic(root / path, new)
        rec = {"class": it.cls, "sha256": mf.sha256(it.kit)}
    old.files[path] = rec
    (root / (path + NEW_SUFFIX)).unlink(missing_ok=True)
    apply.write_atomic(root / mf.PATH, old.dumps())
    apply.git(root, "rm", "-q", "--cached", "--ignore-unmatch", "--", path + NEW_SUFFIX)
    apply.git(root, "add", "-A", "-f", "--", path, mf.PATH)
    apply.git(root, "commit", "-q", "-m", f"foundation: resolve {path} ({choice})")
    print(f"resolved {path}: {choice}")
    return EXIT_OK


def uninstall(root: Path, dry_run: bool = False, allow_dirty: bool = False,
              remove_seeded: bool = False) -> int:
    root = Path(root)
    apply.require_repo(root)
    old = mf.Manifest.read(root)
    if old is None:
        raise InstallError("not installed: no .foundation/manifest.json")
    items = plan.uninstall_plan(root, old, remove_seeded)
    _print_plan(f"fk uninstall {old.kit_version}", items, dry_run)
    if not dry_run:
        _commit(root, f"foundation/uninstall-{old.kit_version}",
                f"foundation: uninstall kit {old.kit_version}", items, None, allow_dirty)
    kept = [it.path for it in items if it.action == "keep" and it.note != "client data"]
    if kept:
        print("kept because the client edited them: " + ", ".join(kept))
    print(GITHUB_STEPS)
    return EXIT_OK

"""Work out what an install, upgrade or uninstall would do, without writing.

Actions (spec §12): create, unchanged, update, conflict, remove, keep. The
write step applies exactly the plan built here, and `--dry-run` prints it.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import fk
from fk.install import manifest as mf
from fk.install import wheel

GITIGNORE = ".gitignore"
BLOCK_START = "# >>> foundation"
BLOCK_END = "# <<< foundation"
NEW_SUFFIX = ".foundation-new"
WRITES = {"create", "update", "conflict", "remove"}


class InstallError(RuntimeError):
    pass


@dataclass
class Desired:
    cls: str
    data: bytes


@dataclass
class Item:
    path: str
    cls: str
    action: str
    kit: bytes | None = None       # the kit's version of the file (or block)
    current: bytes | None = None   # what is on disk now (whole file)
    new: bytes | None = None       # what create/update/remove writes to `path`; None = delete
    note: str = ""


def kit_templates() -> Path:
    """templates/ beside src/ in a kit checkout. `fk init` runs from the kit."""
    path = Path(fk.__file__).resolve().parents[2] / "templates"
    if not (path / "seeded").is_dir():
        raise InstallError("kit templates not found: run fk init/upgrade from a kit checkout")
    return path


def detect_stack(root: Path) -> str:
    return "node" if (root / "package.json").is_file() else "python"


def desired_files(templates: Path, stack: str, version: str = fk.__version__) -> dict[str, Desired]:
    if not (templates / "stacks" / stack).is_dir():
        raise InstallError(f"unknown stack {stack!r}")
    out: dict[str, Desired] = {}
    for base in (templates / "seeded", templates / "stacks" / stack):
        for path in sorted(p for p in base.rglob("*") if p.is_file()):
            out[path.relative_to(base).as_posix()] = Desired(mf.SEEDED, path.read_bytes())
    schemas = Path(fk.__file__).resolve().parent / "schemas"
    for path in sorted(schemas.glob("*.schema.json")):
        out[f".foundation/schemas/{path.name}"] = Desired(mf.MANAGED, path.read_bytes())
    out[f".foundation/vendor/{wheel.wheel_name(version)}"] = Desired(mf.MANAGED, wheel.build(version))
    managed = templates / "managed"
    for path in sorted(p for p in managed.rglob("*") if p.is_file() and p.name != "gitignore.block"):
        out[path.relative_to(managed).as_posix()] = Desired(mf.MANAGED, path.read_bytes())
    out[GITIGNORE] = Desired(mf.BLOCK, (managed / "gitignore.block").read_bytes())
    return out


def _read(root: Path, rel: str) -> bytes | None:
    path = root / rel
    return path.read_bytes() if path.is_file() else None


def split_block(text: bytes | None) -> tuple[bytes, bytes | None, bytes]:
    """(before, block or None, after) of a .gitignore."""
    if text is None:
        return b"", None, b""
    lines = text.splitlines(keepends=True)
    start = next((i for i, l in enumerate(lines) if l.startswith(BLOCK_START.encode())), None)
    if start is None:
        return text, None, b""
    end = next((i for i in range(start, len(lines)) if lines[i].startswith(BLOCK_END.encode())), None)
    if end is None:
        raise InstallError(f"{GITIGNORE}: '{BLOCK_START}' has no matching '{BLOCK_END}'")
    block = b"".join(lines[start:end + 1])
    if not block.endswith(b"\n"):
        block += b"\n"
    return b"".join(lines[:start]), block, b"".join(lines[end + 1:])


def _with_block(current: bytes | None, block: bytes) -> bytes:
    before, old, after = split_block(current)
    if old is None:
        if before and not before.endswith(b"\n"):
            before += b"\n"
        sep = b"\n" if before.strip() else b""
        return before + sep + block
    return before + block + after


def _block_item(root: Path, want: Desired, rec: dict | None) -> Item:
    current = _read(root, GITIGNORE)
    _, block, _ = split_block(current)
    item = Item(GITIGNORE, mf.BLOCK, "unchanged", want.data, current)
    if block == want.data:
        return item
    if block is None or (rec and mf.sha256(block) == rec.get("sha256")):
        item.action = "create" if current is None else "update"
        item.new = _with_block(current, want.data)
    elif rec and rec.get("kept") == mf.sha256(want.data):
        item.action, item.note = "keep", "edited block kept by --resolve"
    else:
        item.action, item.note = "conflict", "managed block edited"
    return item


def _file_item(root: Path, path: str, want: Desired, rec: dict | None) -> Item:
    current = _read(root, path)
    item = Item(path, want.cls, "unchanged", want.data, current)
    kit_sha = mf.sha256(want.data)
    if current is None:
        if rec and want.cls == mf.SEEDED:
            item.action, item.note = "keep", "seeded file removed by the client"
        else:
            item.action, item.new = "create", want.data
    elif mf.sha256(current) == kit_sha:
        pass
    elif rec is None:
        item.action, item.note = "conflict", "file exists and is not the kit's"
    elif want.cls == mf.SEEDED:
        item.action, item.note = "keep", "seeded: belongs to the client"
    elif mf.sha256(current) == rec.get("sha256"):
        item.action, item.new = "update", want.data
    elif rec.get("kept") == kit_sha:
        item.action, item.note = "keep", "edited file kept by --resolve"
    else:
        item.action, item.note = "conflict", "managed file edited by the client"
    return item


def install_plan(root: Path, desired: dict[str, Desired], manifest: mf.Manifest | None) -> list[Item]:
    records = manifest.files if manifest else {}
    items = []
    for path, want in desired.items():
        if want.cls == mf.BLOCK:
            items.append(_block_item(root, want, records.get(path)))
        else:
            items.append(_file_item(root, path, want, records.get(path)))
    # Managed files the kit no longer ships.
    for path, rec in sorted(records.items()):
        if path in desired or rec["class"] != mf.MANAGED:
            continue
        current = _read(root, path)
        if current is None:
            continue
        if mf.sha256(current) == rec.get("sha256"):
            items.append(Item(path, mf.MANAGED, "remove", None, current, None, "no longer shipped"))
        else:
            items.append(Item(path, mf.MANAGED, "keep", None, current, note="no longer shipped; edited"))
    return items


def uninstall_plan(root: Path, manifest: mf.Manifest, remove_seeded: bool = False) -> list[Item]:
    items = []
    for path, rec in sorted(manifest.files.items()):
        current = _read(root, path)
        if rec["class"] == mf.BLOCK:
            before, block, after = split_block(current)
            if block is None:
                continue
            if mf.sha256(block) != rec.get("sha256"):
                items.append(Item(path, mf.BLOCK, "keep", current=current, note="managed block edited"))
                continue
            # Undo _with_block: drop the blank separator line it added.
            rest = (before.rstrip(b"\n") + b"\n" if before.strip() else b"") + after
            items.append(Item(path, mf.BLOCK, "remove", current=current,
                              new=rest if rest.strip() else None, note="block removed"))
            continue
        if current is None:
            continue
        unmodified = mf.sha256(current) == rec.get("sha256")
        if rec["class"] == mf.SEEDED and not remove_seeded:
            items.append(Item(path, rec["class"], "keep", current=current, note="client data"))
        elif unmodified:
            items.append(Item(path, rec["class"], "remove", current=current))
        else:
            items.append(Item(path, rec["class"], "keep", current=current, note="edited by the client"))
    items.append(Item(mf.PATH, mf.MANAGED, "remove", current=_read(root, mf.PATH), note="manifest"))
    return items


def next_manifest(items: list[Item], old: mf.Manifest | None, version: str) -> mf.Manifest:
    """The manifest after applying an install or upgrade plan."""
    files = dict(old.files) if old else {}
    for it in items:
        if it.action == "remove":
            files.pop(it.path, None)
            continue
        rec = dict(files.get(it.path, {}))
        if it.kit is None:
            continue
        kit_sha = mf.sha256(it.kit)
        if it.action in ("create", "update", "unchanged"):
            rec = {"class": it.cls, "sha256": kit_sha}
        elif it.action == "conflict" and it.cls == mf.SEEDED and it.path not in files:
            # A client file that was there before the kit: theirs from now on.
            rec = {"class": mf.SEEDED, "sha256": mf.sha256(it.current)}
        elif not rec:
            continue  # a managed conflict with no record stays unrecorded
        files[it.path] = rec
    return mf.Manifest(kit_version=version, files=files)

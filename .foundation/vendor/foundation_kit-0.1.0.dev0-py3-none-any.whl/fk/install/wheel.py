"""Build the vendored wheel from the running `fk` package, standard library only.

The wheel is byte-for-byte reproducible (sorted entries, fixed timestamps and
modes), so the manifest's SHA-256 changes only when the kit's code does.
"""

from __future__ import annotations

import base64
import hashlib
import io
import zipfile
from pathlib import Path

import fk

DIST = "foundation_kit"
_EPOCH = (1980, 1, 1, 0, 0, 0)
_INCLUDE = (".py", ".json")


def wheel_name(version: str = fk.__version__) -> str:
    return f"{DIST}-{version}-py3-none-any.whl"


def _package_files(package_dir: Path) -> list[tuple[str, bytes]]:
    files = []
    for path in sorted(package_dir.rglob("*")):
        if path.is_file() and path.suffix in _INCLUDE and "__pycache__" not in path.parts:
            arc = "fk/" + path.relative_to(package_dir).as_posix()
            files.append((arc, path.read_bytes()))
    return files


def _record_hash(data: bytes) -> str:
    digest = base64.urlsafe_b64encode(hashlib.sha256(data).digest()).rstrip(b"=").decode()
    return f"sha256={digest}"


def build(version: str = fk.__version__, package_dir: Path | None = None) -> bytes:
    package_dir = package_dir or Path(fk.__file__).resolve().parent
    info = f"{DIST}-{version}.dist-info"
    entries = _package_files(package_dir)
    entries += [
        (f"{info}/METADATA",
         f"Metadata-Version: 2.1\nName: foundation-kit\nVersion: {version}\n"
         "Requires-Python: >=3.11\n".encode()),
        (f"{info}/WHEEL",
         b"Wheel-Version: 1.0\nGenerator: fk\nRoot-Is-Purelib: true\nTag: py3-none-any\n"),
        (f"{info}/entry_points.txt", b"[console_scripts]\nfk = fk.cli:main\n"),
    ]
    record = "".join(f"{name},{_record_hash(data)},{len(data)}\n" for name, data in entries)
    entries.append((f"{info}/RECORD", (record + f"{info}/RECORD,,\n").encode()))

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        for name, data in entries:
            zi = zipfile.ZipInfo(name, date_time=_EPOCH)
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = 0o644 << 16
            zf.writestr(zi, data)
    return buf.getvalue()

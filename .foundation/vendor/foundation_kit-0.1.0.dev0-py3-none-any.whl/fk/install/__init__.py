"""Installer: plan, manifest, init, upgrade and uninstall (spec §12)."""

"""Apply a plan: always on a new branch, atomic writes, one commit (spec §12).

Nothing here decides what to write; it carries out a plan from `plan.py`
exactly, and stages only the paths the plan touched (never `git add -A`).
"""

from __future__ import annotations

import difflib
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

from fk.install import manifest as mf
from fk.install.plan import NEW_SUFFIX, WRITES, InstallError, Item


def git(root: Path, *args: str, check: bool = True) -> str:
    try:
        out = subprocess.run(["git", *args], cwd=root, capture_output=True, text=True)
    except FileNotFoundError as exc:
        raise InstallError("git not found on PATH") from exc
    if check and out.returncode != 0:
        raise InstallError(f"git {' '.join(args)} failed: {out.stderr.strip() or out.stdout.strip()}")
    return out.stdout


def require_repo(root: Path) -> None:
    out = subprocess.run(["git", "rev-parse", "--show-toplevel"], cwd=root,
                         capture_output=True, text=True)
    if out.returncode != 0:
        raise InstallError(f"{root} is not a git repository (run git init first)")
    if Path(out.stdout.strip()).resolve() != root.resolve():
        raise InstallError(f"run from the repository root: {out.stdout.strip()}")


def current_branch(root: Path) -> str:
    return git(root, "symbolic-ref", "--quiet", "--short", "HEAD", check=False).strip()


def require_clean(root: Path) -> None:
    status = git(root, "status", "--porcelain", "--untracked-files=all")
    if status.strip():
        raise InstallError("working tree is not clean; commit or stash first, or pass --allow-dirty")


def branch_exists(root: Path, name: str) -> bool:
    return bool(git(root, "rev-parse", "--verify", "--quiet", f"refs/heads/{name}", check=False).strip())


def write_atomic(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


def _prune_empty_dirs(root: Path, path: Path) -> None:
    parent = path.parent
    while parent != root and parent.is_dir() and not any(parent.iterdir()):
        parent.rmdir()
        parent = parent.parent


def write_plan(root: Path, items: list[Item], manifest: mf.Manifest | None) -> list[str]:
    """Write the plan's files (and the manifest, or remove it when None).
    Returns the repository paths touched."""
    touched = []
    for it in items:
        if it.action not in WRITES or it.path == mf.PATH:
            continue
        target = root / it.path
        if it.action == "conflict":
            write_atomic(root / (it.path + NEW_SUFFIX), it.kit)
            touched.append(it.path + NEW_SUFFIX)
            continue
        if it.new is None:
            target.unlink(missing_ok=True)
            _prune_empty_dirs(root, target)
        else:
            write_atomic(target, it.new)
        touched.append(it.path)
    if manifest is None:
        (root / mf.PATH).unlink(missing_ok=True)
        shutil.rmtree(root / ".foundation" / "runs", ignore_errors=True)
        _prune_empty_dirs(root, root / mf.PATH)
    else:
        write_atomic(root / mf.PATH, manifest.dumps())
    touched.append(mf.PATH)
    return touched


def describe(items: list[Item]) -> list[str]:
    lines = []
    for it in items:
        target = f"{it.path} -> {it.path}{NEW_SUFFIX}" if it.action == "conflict" else it.path
        note = f"  ({it.note})" if it.note else ""
        lines.append(f"  {it.action:<9} {target}{note}")
    counts = {}
    for it in items:
        counts[it.action] = counts.get(it.action, 0) + 1
    order = ["create", "update", "conflict", "remove", "keep", "unchanged"]
    lines.append(", ".join(f"{counts[a]} {a}" for a in order if a in counts))
    return lines


def diffs(items: list[Item]) -> list[str]:
    out = []
    for it in items:
        if it.action not in WRITES:
            continue
        old = it.current or b""
        new = it.kit if it.action == "conflict" else (it.new or b"")
        name = it.path + NEW_SUFFIX if it.action == "conflict" else it.path
        try:
            a, b = old.decode("utf-8"), new.decode("utf-8")
        except UnicodeDecodeError:
            out.append(f"Binary {name}: {len(old)} -> {len(new)} bytes, sha256 {mf.sha256(new)[:12]}")
            continue
        if it.action == "conflict":
            a = ""
        out.extend(difflib.unified_diff(
            a.splitlines(keepends=True), b.splitlines(keepends=True),
            fromfile=f"a/{it.path}" if a else "/dev/null",
            tofile="/dev/null" if it.new is None and it.action == "remove" else f"b/{name}",
        ))
        if out and not out[-1].endswith("\n"):
            out[-1] += "\n"
    return out

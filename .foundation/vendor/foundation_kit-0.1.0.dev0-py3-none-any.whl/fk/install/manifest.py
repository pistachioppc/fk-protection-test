"""`.foundation/manifest.json`: kit version and, per file, its class and hash.

A file's recorded hash is what the kit last wrote (or, for a seeded file that
already existed at install, what the client had). Comparing it with the file
on disk tells a client edit from an untouched kit file.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path

PATH = ".foundation/manifest.json"
MANAGED, SEEDED, BLOCK = "managed", "seeded", "block"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


@dataclass
class Manifest:
    kit_version: str
    files: dict[str, dict] = field(default_factory=dict)

    @classmethod
    def read(cls, root: Path) -> "Manifest | None":
        path = Path(root) / PATH
        if not path.is_file():
            return None
        data = json.loads(path.read_text(encoding="utf-8"))
        return cls(kit_version=data["kit_version"], files=data["files"])

    def dumps(self) -> bytes:
        data = {"kit_version": self.kit_version,
                "files": {k: self.files[k] for k in sorted(self.files)}}
        return (json.dumps(data, indent=2) + "\n").encode()

"""`fk decide "<sentence>"`: record a decision (spec §4.2).

Appends one line to `docs/DECISIONS.md` and creates its entry in
`docs/decisions/D-NNN-slug.md` from a template. The entry is written first
and exclusively, so a crash never leaves a register line pointing nowhere.
"""

from __future__ import annotations

import datetime as dt
import re
from pathlib import Path

from fk import frontmatter, schema, validate
from fk.tasks import slugify, write_atomic

REGISTER = Path("docs") / "DECISIONS.md"
ENTRIES = Path("docs") / "decisions"
STATUSES = ("current", "open")
HEADER = """# Decisions

One line per decision, newest last. `fk decide "<sentence>"` adds one.
"""
BODY = """
## Context

## Decision
{sentence}

## Consequences
"""


class DecisionError(Exception):
    """A refused `fk decide`; the message says why."""


def next_id(root: Path) -> str:
    numbers = []
    register = root / REGISTER
    if register.is_file():
        numbers += [int(n) for n in re.findall(r"^- \*\*D-([0-9]+)\*\*",
                                               register.read_text(encoding="utf-8"), re.M)]
    folder = root / ENTRIES
    if folder.is_dir():
        for path in folder.glob("D-*.md"):
            m = re.match(r"D-([0-9]+)-", path.name)
            if m:
                numbers.append(int(m.group(1)))
    return f"D-{max(numbers, default=0) + 1:03d}"


def decide(root: Path, sentence: str, status: str = "current",
           today: dt.date | None = None) -> tuple[str, Path]:
    """Return (register line, entry path)."""
    sentence = " ".join(sentence.split())
    if not sentence:
        raise DecisionError("the sentence is empty")
    if "→" in sentence:
        raise DecisionError("the sentence must not contain '→' (it separates the register link)")
    if status not in STATUSES:
        raise DecisionError(f"status must be one of {', '.join(STATUSES)}")
    today = today or dt.date.today()
    did = next_id(root)
    entry_rel = f"decisions/{did}-{slugify(sentence)}.md"
    line = f"- **{did}** · {today.isoformat()} · {status} · {sentence} → [entry]({entry_rel})"
    if not validate.REGISTER_LINE.fullmatch(line):
        raise DecisionError(f"internal: register line does not match the format: {line}")
    meta = {"id": did, "title": sentence, "status": status, "date": today}
    problems = schema.validate(meta, schema.load("decision"))
    if problems:
        raise DecisionError("; ".join(problems))

    entry = root / "docs" / entry_rel
    entry.parent.mkdir(parents=True, exist_ok=True)
    with entry.open("x", encoding="utf-8") as fh:
        fh.write(frontmatter.dumps(meta, BODY.format(sentence=sentence)))
    register = root / REGISTER
    text = register.read_text(encoding="utf-8") if register.is_file() else HEADER
    if text and not text.endswith("\n"):
        text += "\n"
    if not text.endswith("\n\n") and not re.search(r"^- \*\*D-", text, re.M):
        text += "\n"
    write_atomic(register, text + line + "\n")
    return line, entry

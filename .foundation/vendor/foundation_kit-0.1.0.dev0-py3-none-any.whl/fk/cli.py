"""Command-line entry point for `fk`.

Exit codes (spec §10): 0 OK, 1 gate or check failure, 2 usage, 3 upgrade
conflict, 4 not enforced.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from fk import __version__

EXIT_OK = 0
EXIT_FAIL = 1
EXIT_USAGE = 2


def _install(func, args: argparse.Namespace, **kwargs) -> int:
    from fk.install.plan import InstallError

    try:
        return func(Path(args.root), **kwargs)
    except InstallError as exc:
        print(f"fk {args.command}: {exc}", file=sys.stderr)
        return EXIT_FAIL


def cmd_init(args: argparse.Namespace) -> int:
    from fk.install import commands

    return _install(commands.init, args, stack=args.stack, dry_run=args.dry_run,
                    allow_dirty=args.allow_dirty)


def cmd_upgrade(args: argparse.Namespace) -> int:
    from fk.install import commands

    if args.resolve:
        return _install(commands.resolve, args, path=args.resolve[0], choice=args.resolve[1])
    return _install(commands.upgrade, args, dry_run=args.dry_run, allow_dirty=args.allow_dirty)


def cmd_uninstall(args: argparse.Namespace) -> int:
    from fk.install import commands

    return _install(commands.uninstall, args, dry_run=args.dry_run, allow_dirty=args.allow_dirty,
                    remove_seeded=args.remove_seeded)


def cmd_validate(args: argparse.Namespace) -> int:
    from fk.validate import validate_repo

    root = Path(args.root)
    if not root.is_dir():
        print(f"fk validate: not a directory: {root}", file=sys.stderr)
        return EXIT_USAGE
    report = validate_repo(root)
    for line in report.problems:
        print(line)
    if report.ok:
        print(f"validate: OK ({report.files} files)")
        return EXIT_OK
    print(f"validate: FAIL ({len(report.problems)} problem(s) in {report.files} files)")
    return EXIT_FAIL


def cmd_task(args: argparse.Namespace) -> int:
    from fk import tasks

    root = Path(args.root)
    try:
        if args.action == "new":
            path = tasks.new(root, args.title)
            print(f"created {path.relative_to(root).as_posix()} (proposed); "
                  "write its definition of done, then `fk task move <id> ready`")
        elif args.action == "move":
            task, left = tasks.move(root, args.id, args.state, branch=args.branch, pr=args.pr)
            print(f"{task.id}: {left} → {task.meta['status']}")
        elif args.action == "show":
            print(tasks.find(root, args.id).text, end="")
        else:
            found, problems = tasks.all_tasks(root)
            for line in problems:
                print(f"unreadable: {line}", file=sys.stderr)
            rows = [t for t in found if not args.status or t.meta.get("status") == args.status]
            for t in rows:
                status = t.meta.get("status", "?")
                if status == "blocked":
                    status += f" (from {t.meta.get('blocked_from', '?')})"
                print(f"{t.meta.get('id', '?'):<8} {status:<24} {t.meta.get('owner', '-'):<10} "
                      f"{t.meta.get('title', '')}")
            if not rows:
                print("no tasks")
            return EXIT_FAIL if problems else EXIT_OK
    except tasks.TaskError as exc:
        print(f"fk task {args.action}: {exc}", file=sys.stderr)
        return EXIT_FAIL
    return EXIT_OK


def cmd_decide(args: argparse.Namespace) -> int:
    from fk import decisions

    try:
        line, entry = decisions.decide(Path(args.root), args.sentence, status=args.status)
    except (decisions.DecisionError, FileExistsError) as exc:
        print(f"fk decide: {exc}", file=sys.stderr)
        return EXIT_FAIL
    print(line)
    print(f"entry: {entry.relative_to(Path(args.root)).as_posix()}")
    return EXIT_OK


def cmd_gate(args: argparse.Namespace) -> int:
    from fk import gate

    root = Path(args.root)
    if not root.is_dir():
        print(f"fk gate: not a directory: {root}", file=sys.stderr)
        return EXIT_USAGE
    report = gate.run_gate(root, rng=args.range)
    for line in gate.render(report):
        print(line)
    return EXIT_OK if report.result == "PASS" else EXIT_FAIL


def cmd_doctor(args: argparse.Namespace) -> int:
    from fk import doctor

    return doctor.doctor(Path(args.root), remote=args.remote, strict=args.strict)


def cmd_protect(args: argparse.Namespace) -> int:
    from fk import protect

    return protect.protect(Path(args.root), apply=args.apply)


def cmd_sync(args: argparse.Namespace) -> int:
    from fk import sync

    return sync.sync(Path(args.root))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="fk", description="Foundation kit")
    parser.add_argument("--version", action="version", version=f"fk {__version__}")
    sub = parser.add_subparsers(dest="command", metavar="<command>")
    p = sub.add_parser("validate", help="check foundation.toml, tasks, decisions and reviews")
    p.add_argument("--root", default=".", help="repository root (default: current directory)")
    p.set_defaults(func=cmd_validate)

    g = sub.add_parser("gate", help="run every configured check; fail closed")
    g.add_argument("--range", help="commit range for {range} (default: commits not on the default branch)")
    g.add_argument("--root", default=".", help="repository root (default: current directory)")
    g.set_defaults(func=cmd_gate)

    o = sub.add_parser("doctor", help="check configuration, tools and (with --remote) GitHub protection")
    o.add_argument("--remote", action="store_true", help="read the ruleset and settings back from GitHub")
    o.add_argument("--strict", action="store_true", help="exit 4 when protection is not enforced")
    o.add_argument("--root", default=".", help="repository root (default: current directory)")
    o.set_defaults(func=cmd_doctor)

    r = sub.add_parser("protect", help="show, then with --apply create, the default-branch ruleset")
    r.add_argument("--apply", action="store_true", help="write the ruleset to GitHub (run by the human)")
    r.add_argument("--root", default=".", help="repository root (default: current directory)")
    r.set_defaults(func=cmd_protect)

    y = sub.add_parser("sync", help="set accepted from merged, human-approved PRs; report mismatches")
    y.add_argument("--root", default=".", help="repository root (default: current directory)")
    y.set_defaults(func=cmd_sync)

    from fk.tasks import STATES

    t = sub.add_parser("task", help="create, move, show and list tasks")
    tsub = t.add_subparsers(dest="action", metavar="<action>", required=True)
    a = tsub.add_parser("new", help="create a proposed task")
    a.add_argument("title")
    a = tsub.add_parser("move", help="move a task along the state machine")
    a.add_argument("id")
    a.add_argument("state", choices=STATES,
                   help="accepted is refused: only fk sync sets it")
    a.add_argument("--branch", help="record the task branch")
    a.add_argument("--pr", type=int, help="record the pull request number")
    a = tsub.add_parser("show", help="print a task file")
    a.add_argument("id")
    a = tsub.add_parser("list", help="list tasks")
    a.add_argument("--status", choices=STATES)
    for action in tsub.choices.values():
        action.add_argument("--root", default=".", help="repository root (default: current directory)")
    t.set_defaults(func=cmd_task)

    d = sub.add_parser("decide", help="record a decision")
    d.add_argument("sentence")
    d.add_argument("--status", choices=["current", "open"], default="current")
    d.add_argument("--root", default=".", help="repository root (default: current directory)")
    d.set_defaults(func=cmd_decide)

    def writer(name: str, help_text: str, func) -> argparse.ArgumentParser:
        w = sub.add_parser(name, help=help_text)
        w.add_argument("--root", default=".", help="repository root (default: current directory)")
        w.add_argument("--dry-run", action="store_true", help="print the plan and diffs; write nothing")
        w.add_argument("--allow-dirty", action="store_true", help="write even if the tree has changes")
        w.set_defaults(func=func)
        return w

    w = writer("init", "install the kit on a new branch", cmd_init)
    w.add_argument("--stack", choices=["python", "node"], help="default: detected")
    w = writer("upgrade", "upgrade managed files on a new branch", cmd_upgrade)
    w.add_argument("--resolve", nargs=2, metavar=("PATH", "keep|theirs"),
                   help="settle one upgrade conflict on the current branch")
    w = writer("uninstall", "remove the kit on a new branch", cmd_uninstall)
    w.add_argument("--remove-seeded", action="store_true",
                   help="also remove unedited seeded files (client data otherwise kept)")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args_list = sys.argv[1:] if argv is None else argv
    try:
        args = parser.parse_args(args_list)
    except SystemExit as exc:
        return exc.code if isinstance(exc.code, int) else EXIT_USAGE
    if not getattr(args, "func", None):
        parser.print_help(sys.stderr)
        return EXIT_USAGE
    return args.func(args)

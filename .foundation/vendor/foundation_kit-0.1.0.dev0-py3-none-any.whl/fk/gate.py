"""`fk gate`: run every `[[checks]]` entry, fail closed (spec §7).

A check passes only when its tool was found, it ran to the end within its
timeout, it exited 0, and (for a test runner) it ran at least one test.
Anything else is a failure, and a required check that did not run is reported
`ran: false`. The gate prints PASS only when every required check passed and
no exception has expired. CI runs the identical command (ticket 06).

The report goes to `.foundation/runs/<UTC time>.json` (git-ignored).
"""

from __future__ import annotations

import datetime as dt
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

import fk
from fk import config

RUNS_DIR = Path(".foundation") / "runs"
DEFAULT_TIMEOUT = 600
TAIL_LINES = 40
LOCKFILES = {
    "python": ("uv.lock", "poetry.lock", "Pipfile.lock", "pdm.lock", "pylock.toml", "requirements.txt"),
    "node": ("package-lock.json", "npm-shrinkwrap.json", "yarn.lock", "pnpm-lock.yaml", "bun.lock",
             "bun.lockb"),
}
# Output that means a runner exited 0 having run nothing.
ZERO_TESTS = re.compile(
    r"^\s*(?:[#ℹ]\s*)?tests 0\s*$"        # node --test (TAP and spec reporters)
    r"|^Tests:\s+0 total"                   # jest
    r"|^\s*0 passing\b"                     # mocha
    r"|\bno tests ran\b",                   # pytest
    re.I | re.M,
)
PYTEST_NO_TESTS = 5


@dataclass
class CheckResult:
    name: str
    run: str
    required: bool
    ran: bool = False
    status: str = "not_run"        # pass | fail | not_run
    reason: str = ""
    exit_code: int | None = None
    seconds: float = 0.0
    output: str = ""


@dataclass
class GateReport:
    result: str = "FAIL"
    kit_version: str = fk.__version__
    started: str = ""
    range: str = ""
    profile: str = ""
    checks: list[CheckResult] = field(default_factory=list)
    problems: list[str] = field(default_factory=list)   # fail the gate
    warnings: list[str] = field(default_factory=list)   # do not
    report_path: str = ""

    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2, ensure_ascii=False) + "\n"


def _git(root: Path, *args: str) -> str | None:
    try:
        out = subprocess.run(["git", *args], cwd=root, capture_output=True, text=True, timeout=60)
    except (OSError, subprocess.TimeoutExpired):
        return None
    return out.stdout.strip() if out.returncode == 0 else None


def default_range(root: Path, default_branch: str) -> str:
    """Commits on HEAD not on the default branch; the whole history when there
    are none to compare against (scanning more is the safe side)."""
    head = _git(root, "rev-parse", "--verify", "-q", "HEAD")
    if head:
        for ref in (f"origin/{default_branch}", default_branch):
            if _git(root, "rev-parse", "--verify", "-q", ref):
                base = _git(root, "merge-base", ref, "HEAD")
                if base and base != head:
                    return f"{base}..HEAD"
    return "HEAD"


def _tool(argv: list[str]) -> str:
    return Path(argv[0]).name


def _is_pytest(argv: list[str]) -> bool:
    return _tool(argv) in ("pytest", "py.test") or argv[1:3] == ["-m", "pytest"]


ANSI = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")


def _tail(text: str) -> str:
    return "\n".join(ANSI.sub("", text).rstrip().splitlines()[-TAIL_LINES:])


def _apply_exceptions(argv: list[str], waivers: list[dict], tmp: Path,
                      warnings: list[str], name: str) -> list[str]:
    """Hand active waivers to tools that can take them; say so when one cannot."""
    if not waivers:
        return argv
    tool = _tool(argv)
    if tool == "pip-audit":
        return argv + [a for w in waivers for a in ("--ignore-vuln", w["id"])]
    if tool == "gitleaks":
        ignore = tmp / f"{name}.gitleaksignore"
        ignore.write_text("".join(f"{w['id']}\n" for w in waivers), encoding="utf-8")
        return argv + ["--gitleaks-ignore-path", str(ignore)]
    for w in waivers:
        warnings.append(f"exception {w['id']} for {name}: {tool} takes no waivers from fk; "
                        "it waives nothing")
    return argv


def run_check(root: Path, check: dict, rng: str, env: dict, timeout: int,
              waivers: list[dict], tmp: Path, warnings: list[str]) -> CheckResult:
    res = CheckResult(check["name"], check["run"], check["required"])
    try:
        argv = [t.replace("{range}", rng) for t in shlex.split(check["run"])]
    except ValueError as exc:
        res.reason = f"not run: cannot parse run ({exc})"
        return res
    if not argv:
        res.reason = "not run: empty command"
        return res
    run_env = dict(env)
    if argv[0] == "fk":
        # The gate's own kit, whether installed, vendored as a wheel or a checkout.
        pkg_parent = str(Path(fk.__file__).resolve().parent.parent)
        run_env["PYTHONPATH"] = os.pathsep.join(p for p in (pkg_parent, env.get("PYTHONPATH")) if p)
        argv = [sys.executable, "-m", "fk", *argv[1:]]
    elif shutil.which(argv[0], path=run_env.get("PATH")) is None:
        res.reason = f"not run: {argv[0]} missing"
        return res
    argv = _apply_exceptions(argv, waivers, tmp, warnings, check["name"])
    start = time.monotonic()
    try:
        proc = subprocess.run(argv, cwd=root, env=run_env, capture_output=True, text=True,
                              errors="replace", timeout=timeout, stdin=subprocess.DEVNULL)
    except subprocess.TimeoutExpired as exc:
        res.seconds = round(time.monotonic() - start, 2)
        out = exc.stdout or ""
        res.output = _tail(out if isinstance(out, str) else out.decode(errors="replace"))
        res.reason = f"not run: timeout after {timeout}s"
        return res
    except OSError as exc:
        res.reason = f"not run: {exc.strerror or exc}"
        return res
    res.seconds = round(time.monotonic() - start, 2)
    res.ran, res.exit_code = True, proc.returncode
    output = proc.stdout + (("\n" + proc.stderr) if proc.stderr else "")
    res.output = _tail(output)
    if proc.returncode == PYTEST_NO_TESTS and _is_pytest(argv):
        res.status, res.reason = "fail", "collected zero tests"
    elif proc.returncode != 0:
        res.status, res.reason = "fail", f"exit {proc.returncode}"
    elif check["name"] == "tests" or _is_pytest(argv):
        if ZERO_TESTS.search(output):
            res.status, res.reason = "fail", "ran zero tests"
        else:
            res.status = "pass"
    else:
        res.status = "pass"
    return res


def _lockfile_present(root: Path, stack: str) -> bool:
    return any((root / name).is_file() for name in LOCKFILES.get(stack, ()))


def run_gate(root: Path, rng: str | None = None, today: dt.date | None = None,
             env: dict | None = None, write: bool = True) -> GateReport:
    root = Path(root)
    env = dict(os.environ if env is None else env)
    today = today or dt.date.today()
    report = GateReport(started=dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"))
    cfg, problems = config.load(root)
    if cfg is None:
        report.problems += [f"{config.CONFIG_FILE}: {p}" for p in problems]
        report.problems.append("no check ran: the configuration is not usable")
        return _finish(root, report, write)

    project = cfg["project"]
    report.profile = project.get("profile", "standard")
    report.range = rng or default_range(root, project["default_branch"])
    waivers: dict[str, list[dict]] = {}
    for exc in cfg.get("exceptions", []):
        if exc["expires"] < today:
            report.problems.append(f"exception {exc['id']} for {exc['check']} expired on "
                                   f"{exc['expires'].isoformat()} (owner {exc['owner']})")
        else:
            waivers.setdefault(exc["check"], []).append(exc)

    with tempfile.TemporaryDirectory(prefix="fk-gate-") as tmp:
        for check in cfg["checks"]:
            if check["name"] == "deps" and not _lockfile_present(root, project["stack"]):
                message = f"deps: no lockfile ({', '.join(LOCKFILES[project['stack']])})"
                if report.profile == "high":
                    report.checks.append(CheckResult(check["name"], check["run"], check["required"],
                                                     status="fail", reason="lockfile missing"))
                    continue
                report.warnings.append(message + "; the high profile fails this")
            report.checks.append(run_check(
                root, check, report.range, env, check.get("timeout", DEFAULT_TIMEOUT),
                waivers.get(check["name"], []), Path(tmp), report.warnings))

    for res in report.checks:
        if res.status == "pass":
            continue
        line = f"{res.name}: {res.reason}"
        if res.required:
            report.problems.append(line)
        else:
            report.warnings.append(line + " (not required)")
    return _finish(root, report, write)


def _finish(root: Path, report: GateReport, write: bool) -> GateReport:
    required = [c for c in report.checks if c.required]
    if not required and report.checks:
        report.problems.append("no required check is configured")
    passed = (not report.problems and bool(required)
              and all(c.ran and c.status == "pass" for c in required))
    report.result = "PASS" if passed else "FAIL"
    if write:
        folder = root / RUNS_DIR
        folder.mkdir(parents=True, exist_ok=True)
        stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        for n in range(1000):
            path = folder / (f"{stamp}.json" if n == 0 else f"{stamp}-{n}.json")
            try:
                with path.open("x", encoding="utf-8"):
                    pass
            except FileExistsError:
                continue
            report.report_path = path.relative_to(root).as_posix()
            path.write_text(report.to_json(), encoding="utf-8")
            break
    return report


def render(report: GateReport) -> list[str]:
    lines = [f"gate: range {report.range}  profile {report.profile}" if report.range else "gate:"]
    for c in report.checks:
        mark = {"pass": "PASS", "fail": "FAIL"}.get(c.status, "NOT RUN")
        if not c.required and c.status != "pass":
            mark = "WARN"
        detail = f"  {c.reason}" if c.reason else ""
        lines.append(f"  {mark:<8}{c.name:<12}{c.seconds:>7.1f}s{detail}")
        if c.status != "pass" and c.output:
            lines += ["    | " + l for l in c.output.splitlines()]
    for w in report.warnings:
        lines.append(f"warning: {w}")
    for p in report.problems:
        lines.append(f"problem: {p}")
    if report.report_path:
        lines.append(f"report: {report.report_path}")
    lines.append(f"gate: {report.result}")
    return lines

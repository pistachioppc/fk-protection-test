"""`fk sync`: acceptance read from GitHub, never from local files (spec §5.1, §4.2).

A task in `review` becomes `accepted` only when its PR is merged and the
human's latest review (approve, request changes or dismissed) is APPROVED by
`[github].human` on the head SHA that was merged. A task already marked
`accepted` is checked the same way; one that fails is a mismatch (a forged or
stale acceptance), reported and left for a person. Exit 1 on any mismatch.
"""

from __future__ import annotations

import datetime as dt
from dataclasses import dataclass
from pathlib import Path

from fk import config as cfg
from fk import frontmatter, tasks
from fk.github import Client, GitHubError, human_token, repo_slug

VERDICTS = ("APPROVED", "CHANGES_REQUESTED", "DISMISSED")


@dataclass
class Acceptance:
    ok: bool
    reason: str
    evidence: str = ""


def judge(pr: dict, reviews: list[dict], human: str, separated: bool = True) -> Acceptance:
    if not pr.get("merged"):
        state = "open" if pr.get("state") == "open" else "closed without merging"
        return Acceptance(False, f"PR #{pr['number']} is {state}")
    head, merge = pr["head"]["sha"], pr.get("merge_commit_sha") or ""
    link = f"PR #{pr['number']} {pr.get('html_url', '')} merged as {merge[:12]}"
    if not separated:
        return Acceptance(True, "merged", f"{link}; SELF-MERGE (not separated): no independent approval")
    mine = [r for r in reviews
            if (r.get("user") or {}).get("login", "").lower() == human.lower() and r.get("state") in VERDICTS]
    if not mine:
        return Acceptance(False, f"PR #{pr['number']} was merged without an approval by {human}")
    last = mine[-1]
    if last["state"] != "APPROVED":
        return Acceptance(False, f"{human}'s last review on PR #{pr['number']} is {last['state']}")
    if last.get("commit_id") != head:
        return Acceptance(False, f"{human} approved {str(last.get('commit_id'))[:12]}, "
                                 f"but {head[:12]} was merged")
    return Acceptance(True, "merged and approved",
                      f"{link}, approved by {human} on {head[:12]} {last.get('html_url', '')}".rstrip())


def add_evidence(body: str, line: str) -> str:
    """Append `- line` at the end of the `## Evidence` section, creating it if absent."""
    lines = body.rstrip("\n").split("\n")
    try:
        start = next(i for i, l in enumerate(lines) if l.strip() == "## Evidence")
    except StopIteration:
        return body.rstrip("\n") + f"\n\n## Evidence\n- {line}\n"
    end = next((i for i in range(start + 1, len(lines)) if lines[i].startswith("## ")), len(lines))
    while end > start + 1 and not lines[end - 1].strip():
        end -= 1
    lines.insert(end, f"- {line}")
    return "\n".join(lines) + "\n"


def accept(task: tasks.Task, evidence: str, today: dt.date) -> None:
    text = frontmatter.update(task.text, {"status": "accepted", "updated": today})
    meta, body = frontmatter.parse(text)
    head = text[: len(text) - len(body)]
    tasks.write_atomic(task.path, head + add_evidence(body, f"accepted {today.isoformat()}: {evidence}"))


def sync(root: Path, today: dt.date | None = None, client: Client | None = None) -> int:
    today = today or dt.date.today()
    config, problems = cfg.load(root)
    if config is None:
        print(f"fk sync: foundation.toml: {'; '.join(problems)}")
        return 1
    human, separated = config["github"]["human"], bool(config["github"]["agent"])
    all_, unreadable = tasks.all_tasks(root)
    mismatches = list(unreadable)
    try:
        repo = repo_slug(root)
        client = client or Client(human_token())
    except GitHubError as exc:
        print(f"fk sync: {exc}")
        return 1
    for task in sorted(all_, key=lambda t: t.id):
        status, number = task.meta.get("status"), task.meta.get("pr")
        if status not in ("review", "accepted"):
            continue
        if not number:
            mismatches.append(f"{task.id}: {status} with no PR recorded")
            continue
        try:
            pr = client.get(f"/repos/{repo}/pulls/{number}")
            reviews = client.pages(f"/repos/{repo}/pulls/{number}/reviews")
        except GitHubError as exc:
            mismatches.append(f"{task.id}: cannot read PR #{number}: {exc}")
            continue
        verdict = judge(pr, reviews, human, separated)
        if status == "accepted":
            if verdict.ok:
                print(f"{task.id}: accepted, confirmed by GitHub")
            else:
                mismatches.append(f"{task.id}: marked accepted, but {verdict.reason}")
        elif verdict.ok:
            accept(task, verdict.evidence, today)
            print(f"{task.id}: review -> accepted ({verdict.evidence})")
        elif pr.get("state") == "open":
            print(f"{task.id}: in review, waiting ({verdict.reason})")
        else:
            mismatches.append(f"{task.id}: in review, but {verdict.reason}")
    for line in mismatches:
        print(f"MISMATCH {line}")
    return 1 if mismatches else 0
